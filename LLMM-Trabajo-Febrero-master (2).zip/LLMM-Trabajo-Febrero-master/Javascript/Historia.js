function cambiar_color_over(celda){ 

    celda.style.backgroundColor="green"
    celda.style.color= "red"
    celda.style.fontSize= "20px"
    } 
function cambiar_color_out(celda){ 
   celda.style.backgroundColor=""
   celda.style.color="";
   celda.style.fontSize= ""
   } 