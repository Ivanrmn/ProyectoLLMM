function myFunction() {
    alert("El formulario se ha enviado correctamente.");
}